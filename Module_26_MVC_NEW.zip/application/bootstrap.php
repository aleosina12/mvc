<?php
require_once 'C:\dev\Skillfactory\Module_26_MVC_NEW\application\core\model.php';
require_once 'C:\dev\Skillfactory\Module_26_MVC_NEW\application\core\view.php';
require_once 'C:\dev\Skillfactory\Module_26_MVC_NEW\application\core\controller.php';
require_once 'C:\dev\Skillfactory\Module_26_MVC_NEW\application\core\route.php';

Route::start(); // запускаем маршрутизатор
