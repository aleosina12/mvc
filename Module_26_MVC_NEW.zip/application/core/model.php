<?php
class Model
{
    public $string;
    public function get_data(){
        $this->string = "MVC + PHP = Awesome, click here!";
    }
}