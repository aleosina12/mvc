<?php

class Model_Portfolio extends Model

{

    public function  get_data ()
    {
        return array (
            array (
                'Year' => '2012',
                'Site' => 'http://beer.ru',
                'Description' => 'Good site about beer'
            )

        )


    }
}
