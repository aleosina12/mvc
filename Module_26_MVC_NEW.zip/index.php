<?php

ini_set ('display_errors', 1);
require_once  'C:\dev\Skillfactory\Module_26_MVC_NEW\application\bootstrap.php';
